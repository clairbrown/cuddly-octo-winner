from flask import Flask
app= Flask(__name__)
@app.route("/")
def helloWorld():
    return "Like a joke or something"
@app.route("/dojo")
def dojo():
    return "Dojo!"
@app.route('/say/<name>')
def hello(name):
    return "Sup, " +str(name)
@app.route('/repeat/<num>/<word>')
def repeat(num,word):
    return (str(word) + " " )* int(num)
@app.route('/<anything>')
def heck(anything):
    return "You hecked up my dude"
if __name__=="__main__":
    app.run(debug=True)

