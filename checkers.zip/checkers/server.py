from flask import Flask,render_template
app= Flask(__name__)

@app.route('/')
def index():
    return render_template("index.html",rowTimes=4, columnTimes=4,shadeOne="red",shadeTwo="black")

@app.route('/<rows>')
def defineRows(rows):
    if int(rows)%2 !=0:
        return "Oh no you dont!"
    return render_template("index.html",rowTimes=int(int(rows)/2), columnTimes=4,shadeOne="red",shadeTwo="black")

@app.route('/fullcontrol/<rows>/<columns>/<colorOne>/<colorTwo>')
def fullControl(rows,columns,colorOne,colorTwo):
    if int(rows)%2 !=0:
        return "Oh no you dont!"
    if int(columns)<8:
        return "Seriously. Don't, it freaks out and I dont feel like figuring this out"
    return render_template("index.html",rowTimes=int(int(rows)/2), columnTimes=int(int(columns)/2),shadeOne=colorOne,shadeTwo=colorTwo)

if __name__=="__main__":
    app.run(debug=True)